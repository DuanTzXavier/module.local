package top.basking.module.demo;

public class DemoString {
    public String a = "2";
}
