package com.example.myapplication

import android.content.Context
import android.graphics.Rect
import android.graphics.Region
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.TouchDelegate
import android.view.View
import java.lang.Exception
import java.util.*
import java.util.concurrent.locks.ReentrantLock

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

//        window.decorView.addOnLayoutChangeListener()

        val b = Rect()

        val a = Region()

        val c = HashMap<Int, Int>()
        c.size

//        val t = Thread()
//        t.interrupt()
////        inline
////        t.stop()
//
//        val o = Object()
//        o.wait()
//        o.wait(100)
//
//        val lock = ReentrantLock()
//        val condition = lock.newCondition()
//        condition.signal()
//        condition.await()
//        lock.isHeldByCurrentThread




    }

    class ListNode{
        var value = 0
        var next: ListNode? = null
    }

    private fun mergeSortedList(l1: ListNode?, l2: ListNode?): ListNode?{
        if (l1 == null) return l2
        if (l2 == null) return l1
        if (l1.value > l2.value){
            l2.next = mergeSortedList(l2.next, l1)
            return l2
        }else{
            l1.next = mergeSortedList(l1.next, l2)
            return l1
        }
    }

    private fun getCycleListNode(head: ListNode?): ListNode?{
        var fast = head
        var slow = head
        var isCycle = false
        while(fast != null && fast.next != null){
            fast = fast?.next?.next
            slow = slow?.next
            if(fast == slow){
                isCycle = true
                break
            }
        }

        if (!isCycle) return null

        fast = head
        while(fast != slow){
            fast = fast?.next
            slow = slow?.next
        }

        return fast
    }

    private fun revertList2(head: ListNode?): ListNode?{
        var cur = head
        var pre:ListNode? = null
        while(cur != null){
            val next = cur.next
            cur.next = pre
            pre = cur
            cur = next
        }
        return pre
    }

    private fun revertList(head: ListNode?): ListNode?{
        if(head?.next == null) return head
        val cur = revertList(head.next)
        head.next?.next = head
        head.next = null
        return cur
    }

    class A @JvmOverloads constructor(
        context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
    ) : View(context, attrs, defStyleAttr) {

    }

    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean {
        Exception().printStackTrace()
        return super.dispatchTouchEvent(ev)
    }
}